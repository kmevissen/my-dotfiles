from __future__ import absolute_import

import setuptools

setuptools.setup(
    name='beam-protos',
    version='0.0.1',
    description='Protos for Beam jobs',
    packages=setuptools.find_packages(),
)
